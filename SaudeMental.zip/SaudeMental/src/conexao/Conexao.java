package conexao;

import java.sql.Connection;
import java.sql.DriverManager;

public class Conexao {
       public Connection getConexao () {
            try{

                Connection conn = DriverManager.getConnection(
                           "jdbc:mysql://localhost:3000/test", 
                           "root", 
                           "1234"
                );
return conn;
}catch(Exception e) {

System.out.println("Erro conexão:" + e.getMessage());
return null;
}
}
}
