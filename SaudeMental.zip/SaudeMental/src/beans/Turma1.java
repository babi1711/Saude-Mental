/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package beans;

/**
 *
 * @author vitor
 */
public class Turma1 {
    
    private int id;
private String nome;
private String sentimento;
private java.sql.Date data;
public int getId() {
return id;
}
public void setId(int id) {
this.id = id;
}
public String getnome() {
return nome;
}
    public void setnome (String nome this.nome nome;
}
public String getsentimento() {
return sentimento;
}
public void setsentimento (string sentimento) {
this.sentimento = sentimento;
}
private java.sql.Date data () {
return data;
}
public void setData (double data) {
this.preco = preco;
}


